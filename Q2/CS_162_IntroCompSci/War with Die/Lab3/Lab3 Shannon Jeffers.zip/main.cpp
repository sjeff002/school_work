
#include "Game.hpp"
#include <iostream>

using namespace std;

int main() {
	Game g1;

	g1.playGame();

	return 0;
}